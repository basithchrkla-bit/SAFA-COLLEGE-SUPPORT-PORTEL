# SAFA QURAN COLLEGE SUPPORT PORTAL V2

Mobile-friendly front-end prototype for Parent, Teacher and Super Admin.

## Demo logins
- Parent: `1001` / `1234`
- Teacher: `ustad1` / `1234`
- Super Admin: `admin` / `admin123`

## Important
This is still a front-end demo. Login/data are stored in the browser code and are NOT secure for real student data.

Next stage: connect Firebase Authentication + Firestore and add real role-based security.
